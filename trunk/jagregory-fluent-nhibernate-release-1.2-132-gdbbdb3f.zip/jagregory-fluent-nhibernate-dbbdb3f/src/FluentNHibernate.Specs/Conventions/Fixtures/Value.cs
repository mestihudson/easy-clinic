﻿namespace FluentNHibernate.Specs.Conventions.Fixtures
{
    public class Value
    {
        public string Property { get; set; }
    }
}