using System;

namespace FluentNHibernate.Specs.FluentInterface.Fixtures
{
    class EntityWithVersion
    {
        public TimeSpan VersionNumber { get; set; }
    }
}