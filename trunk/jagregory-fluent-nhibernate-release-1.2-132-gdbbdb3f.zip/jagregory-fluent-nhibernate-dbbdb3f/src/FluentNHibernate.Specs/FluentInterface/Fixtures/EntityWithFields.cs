namespace FluentNHibernate.Specs.FluentInterface.Fixtures
{
    class EntityWithFields
    {
        public string Name;
    }
}