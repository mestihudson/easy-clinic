﻿using NUnit.Framework;

namespace FluentNHibernate.Testing
{
    [TestFixture]
    public class Debugging
    {
        [Test]
        public void Break()
        {
            //Assert.Fail("Make it break");
        }
    }
}